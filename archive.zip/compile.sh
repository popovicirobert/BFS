#!/bin/bash

#gcc -O2 -std=c99 main.c -o main
g++ -std=c++11 -O2  main.cpp -o main
