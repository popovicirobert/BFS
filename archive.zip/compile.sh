#!/bin/bash

g++ -std=c++11 -O2 main.cpp -fopenmp -o main
