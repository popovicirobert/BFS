#!/bin/bash

gcc -O2 -std=c99 -fopenmp main2.c -o main
#g++ -std=c++11 -O2  main.cpp -o main
