#!/bin/bash

gcc -O2 main.c -o main
