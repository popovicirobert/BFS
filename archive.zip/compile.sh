#!/bin/bash

gcc -O2 -std=c99 main.c -o main
