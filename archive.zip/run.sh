#!/bin/bash

./main < $1 > ans.txt
